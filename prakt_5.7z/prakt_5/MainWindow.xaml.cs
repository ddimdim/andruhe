﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace prakt_5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Page[] pages = new Page[]
            {
               new Pages.RoutingPage(),
               new Pages.AttacheEventsPage(),
               new Pages.TextBoxPage(),
               new Pages.ValidationInputPage()
            };
        public MainWindow()
        {
            InitializeComponent();

        }

        private void PageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb.SelectedIndex == 0)
            {
                MainFrame.Navigate(pages[0]);
            }
            else if (cb.SelectedIndex == 1)
            {
                MainFrame.Navigate(pages[1]);
            }
            else if (cb.SelectedIndex == 2)
            {
                MainFrame.Navigate(pages[2]);
            }
            else if (cb.SelectedIndex == 3)
            {
                MainFrame.Navigate(pages[3]);
            }
        }
    }

}

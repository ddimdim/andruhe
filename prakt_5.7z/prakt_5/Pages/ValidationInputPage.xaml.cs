﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace prakt_5.Pages
{
    /// <summary>
    /// Логика взаимодействия для ValidationInputPage.xaml
    /// </summary>
    public partial class ValidationInputPage : Page
    {
        public ValidationInputPage()
        {
            InitializeComponent();
        }

        private void NameTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (e.Text.Any(symbol => !char.IsLetter(symbol)))
            {
                e.Handled = true;
            }
        }

        private void IdTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (e.Text.Any(symbol => !char.IsDigit(symbol)))
            {
                e.Handled = true;
            }
        }

        private void IdTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private void IdTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (IdTextBox.Text.StartsWith("0"))
            {
                IdTextBox.Text = IdTextBox.Text.TrimStart('0');
            }

        }

        private void AgeTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (e.Text.Any(symbol => !char.IsDigit(symbol)))
            {
                e.Handled = true;
            }
        }


        private void AgeTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (AgeTextBox.Text.Length > 1)
            {
                if (e.Key != Key.Back)
                {
                    e.Handled = true;
                }
            }
        }

        private void PhoneTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (e.Text.Any(symbol => !char.IsDigit(symbol)))
            {
                e.Handled = true;
            }
        }

        private void PhoneTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (PhoneTextBox.Text.Length > 10 || e.Key != Key.D8 && PhoneTextBox.Text.Length == 0)
            {
                if (e.Key != Key.Back)
                {
                    e.Handled = true;
                }
            }
        }
    }
}
